﻿using Newtonsoft.Json.Linq;
using System;
using System.Xml.Linq;

internal class Program
{
    private static void Main(string[] args)
    {
        int producedPower = 0;

        while (producedPower == 0)
        {
            producedPower = GetProducedPower();
            Thread.Sleep(5000); // Wartet 5 Sekunden, bevor der API-Aufruf wiederholt wird
        }
        string outputPath = @"D:\UserData\z0044dju\Documents\standard.sdt";

        // Schreiben der produzierten Energie in eine Textdatei
        System.IO.File.AppendAllText(outputPath, producedPower.ToString() + Environment.NewLine);

    }

    public static int totalEnergyOutput;
    public static int lastNonZeroEnergyOutput;
    public static int energyOutputWh;

    public static int GetProducedPower()
    {
        string today = DateTime.Now.ToString("yyyy-MM");

        string apiUrl = string.Format("https://api.solarweb.com/swqapi/pvsystems/cf9cd08a-7660-49cf-a401-715774713d1e/aggrdata?from=2022-10&to={0}&channel=EnergyOutput", today);

        string accessKeyId = "FKIAC9737F1E2CCC49E697C448D4BFE88FEE";
        string accessKeyValue = "f8adb3ea-3101-424b-aa42-737a417e1fac";

        HttpClient httpClient = new HttpClient();

        httpClient.DefaultRequestHeaders.Add("AccessKeyId", accessKeyId);
        httpClient.DefaultRequestHeaders.Add("AccessKeyValue", accessKeyValue);

        HttpResponseMessage response = httpClient.GetAsync(apiUrl).Result;

        string responseContent = response.Content.ReadAsStringAsync().Result;

        JObject responseJson = JObject.Parse(responseContent);
        JArray data = (JArray)responseJson["data"];

        int totalEnergyOutput = 0;
        foreach (var log in data)
        {
            JArray channels = (JArray)log["channels"];
            foreach (var channel in channels)
            {
                if ((string)channel["channelName"] == "EnergyOutput")
                {
                    int energyOutputWh = (int)channel["value"];
                    totalEnergyOutput += energyOutputWh;

                }
            }
        }


        totalEnergyOutput = (int)Math.Round(totalEnergyOutput / 1000.0, MidpointRounding.AwayFromZero);


        return totalEnergyOutput * 2;
    }
}

